  SmartMenus v5.5
  The package for professionals!
===================================================


====================INSTRUCTIONS===================

  The "Basic Example" folder contains the SmartMenus v5.5 with a
basic example of the script capabilities.

  The "Frame Support" folder contains two small scripts you should use
in combination with the SmartMenus script for framed pages.

  The "Add-ons" folder contains add-ons for the SmartMenus.

  The "Samples" folder contains some samples.

==================INSTRUCTIONS END=================