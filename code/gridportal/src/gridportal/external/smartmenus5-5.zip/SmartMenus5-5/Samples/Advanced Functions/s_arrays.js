// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='newWindow';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSSTop=[
'#4A49A8',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
1,		// BorderWidth
'#CBCBEF',	// BgColor
1,		// Padding
'#CBCBEF',	// ItemBgColor
'#4A49A8',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
3,		// ItemPadding
1,		// ItemSeparatorSize
'#8A8CCC',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
true,				// UseSubImg
'../../images/arrow4.gif',		// SubImgSrc
'../../images/arrow4over.gif',	// OverSubImgSrc
7,				// SubImgWidth
7,				// SubImgHeight
9,				// SubImgTop px (from item top)
'#8A8CCC',			// SELECTED ItemBgColor
'#FFFFFF',			// SELECTED ItemFontColor
'../../images/arrow4over.gif',	// SELECTED SubImgSrc
true,				// UseScrollingForTallMenus
'../../images/scrolltop.gif',	// ScrollingImgTopSrc
'../../images/scrollbottom.gif',	// ScrollingImgBottomSrc
68,				// ScrollingImgWidth
12,				// ScrollingImgHeight
'normal',		// ItemClass (css)
'over',			// ItemOverClass (css)
'selected',		// SELECTED ItemClass (css)
0,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#FFFFFF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#FFFFFF',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];


// FUNCTIONS FOR GETTING MENU DIMENTIONS AND POSITION
function s_getDim(name,a){
var o=s_nS4?document.layers["s_m"+s_nr(name)]:s_getO("s_m"+s_nr(name));
if(!o)
	return 0;
if(s_nS4)
	return a=="h"?o.clip.height:o.clip.width;
if(a=="h")
	return s_iE&&!s_mC?o.clientHeight:o.offsetHeight?o.offsetHeight:o.style.pixelHeight;
return s_iE&&!s_mC?o.clientWidth:s_oP7m?o.style.w:o.offsetWidth;
}

function s_getPos(name,a){
var o=s_nS4?document.layers["s_m"+s_nr(name)]:s_getO("s_m"+s_nr(name));
if(!o)
	return 0;
if(!s_nS4)
	o=o.style;
return a=="l"?parseInt(o.left):parseInt(o.top);
}
// FUNCTIONS FOR GETTING MENU DIMENTIONS AND POSITION


// CODE USED FOR REPOSITIONING PERMANENT MENUS WHILE PAGE LOADING
function s_whilePageLoading(){if(typeof s_ML=="undefined"){setTimeout("s_whilePageLoading()",1000);return};var px=s_oP7m||s_nS4?0:"px",os=null,x,y,i,S;for(i=0;i<s_P.length;i++){S=s_[s_P[i]][0];if(typeof(S.T)=="number"&&typeof(S.L)=="number")continue;os=s_nS4?document.layers["s_m"+s_P[i]]:s_getOS("s_m"+s_P[i]);os.left=eval(S.L)+px;os.top=eval(S.T)+px};if(typeof s_Bl=="undefined")setTimeout("s_whilePageLoading()",1000)};s_whilePageLoading();s_ol=window.onload?window.onload:function(){};window.onload=function(){setTimeout('s_Bl=1',3000);s_ol()}
// CODE USED FOR REPOSITIONING PERMANENT MENUS WHILE PAGE LOADING


// EXAMPLE FUNCTION FOR CENTERING A HORIZONTAL MENU
function s_centerHorizontalMenu(){
var windowWidth,menuWidth=0,scrollBarFix,i;

scrollBarFix=s_nS&&!document.body.clientWidth?15:s_nS4&&innerWidth<document.width?16:0;

windowWidth=s_iE?s_dE.clientWidth:s_nS&&document.body.clientWidth&&!s_sF?s_dE.clientWidth?s_dE.clientWidth:document.body.clientWidth:s_oP7?document.body.clientWidth:innerWidth-scrollBarFix;

for(i=0;i<arguments.length;i++){
	menuWidth+=s_getDim(arguments[i],"w");
	menuWidth-=i<arguments.length-1?1:0; // substract border overlapping
}

return parseInt(windowWidth/2-menuWidth/2);
}
// EXAMPLE FUNCTION FOR CENTERING A HORIZONTAL MENU


// === 4 === MENU DEFINITIONS
s_add(
{N:'H1',	// NAME
LV:1,		// LEVEL
T:100,		// TOP
L:'s_centerHorizontalMenu("H1","H2","H3","H4","H5")',	// LEFT
P:true,		// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSSTop	// STYLE Array to use for this menu
},
[
{Show:'search',U:'',T:'Search'}
]
);

s_add(
{N:'H2',LV:1,T:'s_getPos("H1","t")',L:'s_getPos("H1","l")+s_getDim("H1","w")-1',P:true,S:s_CSSTop},
[
{Show:'e_mail',U:'',T:'E-mail (up-left)',SubImgSrc:'../../images/arrow5.gif',OverSubImgSrc:'../../images/arrow5over.gif',SubImgTop:6}
]
);

s_add(
{N:'H3',LV:1,T:'s_getPos("H1","t")',L:'s_getPos("H2","l")+s_getDim("H2","w")-1',P:true,S:s_CSSTop},
[
{Show:'masters',U:'',T:'Masters'}
]
);

s_add(
{N:'H4',LV:1,T:'s_getPos("H1","t")',L:'s_getPos("H3","l")+s_getDim("H3","w")-1',P:true,S:s_CSSTop},
[
{U:'',T:'SELECTED',SELECTED:true}
]
);

s_add(
{N:'H5',LV:1,T:'s_getPos("H1","t")',L:'s_getPos("H4","l")+s_getDim("H4","w")-1',P:true,S:s_CSSTop},
[
{Show:'disabled',U:'',T:'DISABLED (below)'}
]
);

	s_add(
	{N:'search',LV:2,MinW:130,T:'s_getDim("H1","h")+s_getPos("H1","t")-1',L:'s_getPos("H1","l")',P:false,S:s_CSSTop},
	[
	{U:'http://www.google.com/',T:'Google'},
	{U:'http://www.altavista.com/',T:'Altavista'},
	{U:'http://www.search.com/',T:'CNET Search.com'},
	{U:'http://www.lycos.com/',T:'Lycos'},
	{U:'http://www.hotbot.com/',T:'Hotbot'}
	]
	);

	s_add(
	{N:'e_mail',LV:2,MinW:130,T:'s_getPos("H2","t")-s_getDim("e_mail","h")+1',L:'s_getPos("H2","l")-s_getDim("e_mail","w")+s_getDim("H2","w")',P:false,S:s_CSSTop},
	[
	{U:'http://mail.yahoo.com/',T:'Yahoo!'},
	{U:'http://www.hotmail.com/',T:'Hotmail'},
	{U:'http://www.mail.com/',T:'Mail.com'}
	]
	);

	s_add(
	{N:'masters',LV:2,MinW:130,T:'s_getDim("H3","h")+s_getPos("H3","t")-1',L:'s_getPos("H3","l")',P:false,S:s_CSSTop},
	[
	{U:'http://www.hotscripts.com/',T:'HotScripts'},
	{U:'http://www.builder.com/',T:'Builder'},
	{U:'http://www.webreference.com/',T:'Webreference'},
	{U:'http://msdn.microsoft.com/',T:'MSDN'},
	{U:'http://www.perl.com/',T:'Perl'},
	{U:'http://www.w3.org/',T:'W3C'}
	]
	);

	s_add(
	{N:'disabled',LV:2,W:160,T:'s_getDim("H5","h")+s_getPos("H5","t")-1',L:'s_getPos("H5","l")',P:false,S:s_CSSTop},
	[
	{U:'',T:'This is a menu item with "<font color=#000000><i>DISABLED:true</i></font>" set. It is optimized as a HTML container. You can use all kind of HTML tags in the content of such items. As you can see, it\'s not a problem to include images <img src=../../images/ico.gif width=12 height=12 align=top> or <a href=http://www.smartmenus.org/ target=_blank>custom links</a>.<br><br>Please don\'t forget to use fixed width (the "<font color=#000000><i>W</i></font>" menu property) for menus containing items with long text. Otherwise the text won\'t wrap.',DISABLED:true,Class:'',FontWeight:'normal'}
	]
	);

s_add(
{N:'my_menu',LV:1,T:15,L:'mouseX+10',P:false,S:s_CSSTop},
[
{U:'../../Manual/manual.html',T:'User\'s Manual',Target:'self',SeparatorSize:0},
{U:'../../Manual/forum.html',T:'Forum',Target:'self',SeparatorSize:0},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author',Target:'self'},
{U:'javascript:alert("SmartMenus (tm) 5\\nAdvanced DHTML navigation system.\\n\\nVersion: 5.5 (Release 31)\\nRelease date: March 16, 2005\\n\\n(c) 2001-2005 Vasil Dinkov - Plovdiv, BULGARIA\\n(c) 2003-2005 ET Vadikom-Vasil Dinkov\\nAll rights reserved.")',T:'About'}
]
);