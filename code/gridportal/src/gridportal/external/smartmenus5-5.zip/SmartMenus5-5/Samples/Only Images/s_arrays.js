// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='self';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSSpermanent=[
'#4A49A8',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
0,		// BorderWidth
'transparent',	// BgColor
0,		// Padding
'transparent',	// ItemBgColor
'transparent',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
0,		// ItemPadding
0,		// ItemSeparatorSize
'#8A8CCC',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
false,		// UseSubImg
'',		// SubImgSrc
'',		// OverSubImgSrc
0,		// SubImgWidth
0,		// SubImgHeight
0,		// SubImgTop px (from item top)
'#8A8CCC',	// SELECTED ItemBgColor
'#FFFFFF',	// SELECTED ItemFontColor
'',		// SELECTED SubImgSrc
false,		// UseScrollingForTallMenus
'',		// ScrollingImgTopSrc
'',		// ScrollingImgBottomSrc
0,		// ScrollingImgWidth
0,		// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
0,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#FFFFFF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#FFFFFF',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];

s_CSSTop=[
'#4A49A8','#4A49A8',1,'#CBCBEF',2,'transparent','transparent','#4A49A8','#FFFFFF','verdana,arial,helvetica,sans-serif','10px','1','bold','left',3,0,'#B1B2E7','',true,'../../images/arrow.gif','../../images/arrowover.gif',7,7,5,'#8A8CCC','#FFFFFF','../../images/arrowover.gif',true,'../../images/scrolltop.gif','../../images/scrollbottom.gif',68,12,'','','',1,'transparent','#FFFFFF','#FFFFFF',0,''];


// === 4 === MENU DEFINITIONS
s_add(
{
N:'permanent',	// NAME
LV:1,		// LEVEL (look at IMPORTANT NOTES 1 in the Manual)
W:150,		// WIDTH
T:120,		// TOP (look at IMPORTANT HOWTOS 6 in the Manual)
L:15,		// LEFT (look at IMPORTANT HOWTOS 6 in the Manual)
P:true,		// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSSpermanent	// STYLE Array to use for this menu
},
[
{Image:['1.gif',150,21],U:'',T:''},
{Image:['2.gif',150,19],OnImage:'2_on.gif',U:'../../update.html',T:''},
{Image:['3.gif',150,19],OnImage:'3_on.gif',U:'../../compatibility.html',T:''},
{Image:['4.gif',150,19],OnImage:'4_on.gif',U:'../../Manual/forum.html',T:''},
{Image:['5.gif',150,20],OnImage:'5_on.gif',U:'mailto:smartmenus@smartmenus.org',T:''}
]
);

s_add(
{N:'my_menu',MinW:140,LV:1,T:15,L:'mouseX+10',P:false,S:s_CSSTop,BGI:'menu_bg.gif'},
[
{U:'../../Manual/manual.html',T:'&nbsp; &nbsp;User\'s Manual',OnBgImage:'bg.gif',Image:['../../images/x.gif',12,12],ImageA:'top'},
{U:'../../Manual/forum.html',T:'&nbsp; &nbsp;Forum',OnBgImage:'bg.gif',Image:['../../images/x.gif',12,12],ImageA:'top'},
{U:'mailto:smartmenus@smartmenus.org',T:'&nbsp; &nbsp;Contact the author',SeparatorSize:1,OnBgImage:'bg.gif',Image:['../../images/x.gif',12,12],ImageA:'top'},
{U:'javascript:alert("SmartMenus (tm) 5\\nAdvanced DHTML navigation system.\\n\\nVersion: 5.5 (Release 31)\\nRelease date: March 16, 2005\\n\\n(c) 2001-2005 Vasil Dinkov - Plovdiv, BULGARIA\\n(c) 2003-2005 ET Vadikom-Vasil Dinkov\\nAll rights reserved.")',T:'&nbsp; &nbsp;About',OnBgImage:'bg.gif',Image:['../../images/ico.gif',12,12],OnImage:'../../images/ico_on.gif',ImageA:'top'}
]
);