// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='self';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSS1=[
'#4A49A8',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
1,		// BorderWidth
'transparent',	// BgColor
0,		// Padding
'#CBCBEF',	// ItemBgColor
'#4A49A8',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
3,		// ItemPadding
1,		// ItemSeparatorSize
'transparent',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
false,		// UseSubImg
'',		// SubImgSrc
'',		// OverSubImgSrc
0,		// SubImgWidth
0,		// SubImgHeight
0,		// SubImgTop px (from item top)
'transparent',			// SELECTED ItemBgColor
'#FFFFFF',			// SELECTED ItemFontColor
'../images/arrowover.gif',	// SELECTED SubImgSrc
false,		// UseScrollingForTallMenus
'',		// ScrollingImgTopSrc
'',		// ScrollingImgBottomSrc
0,		// ScrollingImgWidth
0,		// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
0,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#FFFFFF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#FFFFFF',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];


// SAMPLE FUNCTION USED FOR RELATIVE POSITIONING
function s_getStart(a){

var bodyMarginTop=0;// specify manually to get over bugs
var bodyMarginLeft=0;// in Opera 5/6, Konqueror<3.2 and IE5.x/Mac

var o=document.images["getStart"];if(!o)return a=="x"?-630:0;

if(s_nS4)return a=="x"?o.x:o.y;
var oP,oC,ieW;oP=o.offsetParent;oC=a=="x"?o.offsetLeft:o.offsetTop;
ieW=s_iE&&!s_mC?1:0;
while(oP){if(ieW&&oP.tagName&&oP.tagName.toLowerCase()=="table"&&oP.border&&oP.border>0)oC++;oC+=a=="x"?oP.offsetLeft:oP.offsetTop;oP=oP.offsetParent};
return s_oP7m||s_kN31p&&!s_kN32p||s_iE5M?a=="x"?s_oP7m?oC:oC+bodyMarginLeft:oC+bodyMarginTop:oC};
/*
 All browsers have problems with finding the real position of an
 element on the page in certain cases. I have tried to get over some
 browser bugs with the above function- that's why it's so complex.
*/
// SAMPLE FUNCTION USED FOR RELATIVE POSITIONING


// CODE USED FOR REPOSITIONING PERMANENT MENUS WHILE PAGE LOADING
function s_whilePageLoading(){if(typeof s_ML=="undefined"){setTimeout("s_whilePageLoading()",1000);return};var px=s_oP7m||s_nS4?0:"px",os=null,x,y,i,S;for(i=0;i<s_P.length;i++){S=s_[s_P[i]][0];if(typeof(S.T)=="number"&&typeof(S.L)=="number")continue;os=s_nS4?document.layers["s_m"+s_P[i]]:s_getOS("s_m"+s_P[i]);os.left=eval(S.L)+px;os.top=eval(S.T)+px};if(typeof s_Bl=="undefined")setTimeout("s_whilePageLoading()",1000)};s_whilePageLoading();s_ol=window.onload?window.onload:function(){};window.onload=function(){setTimeout('s_Bl=1',3000);s_ol()}
// CODE USED FOR REPOSITIONING PERMANENT MENUS WHILE PAGE LOADING


// === 4 === MENU DEFINITIONS
s_add(
{
N:'permanent_1',// NAME
LV:1,		// LEVEL (look at IMPORTANT NOTES 1 in the Manual)
MinW:150,	// MINIMAL WIDTH
T:'s_getStart("y")',	// TOP (look at IMPORTANT HOWTOS 6 in the Manual)
L:'s_getStart("x")',	// LEFT (look at IMPORTANT HOWTOS 6 in the Manual)
P:true,		// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSS1	// STYLE Array to use for this menu
},
[		// define items {U:'url',T:'text' ...} look at the Manual for details
{U:'',T:'permanent_1',SeparatorColor:'#ffffff',SELECTED:true,TextAlign:'right'},
{U:'../../../update.html',T:'Update SmartMenus'},
{U:'../../../compatibility.html',T:'Compatibility tests'},
{U:'../../../Manual/forum.html',T:'Forum'},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author'}
]
);

s_add(
{N:'permanent_2',LV:1,MinW:150,T:'s_getStart("y")',L:'s_getStart("x")+200',P:true,S:s_CSS1},
[
{U:'',T:'permanent_2',SeparatorColor:'#ffffff',SELECTED:true},
{U:'../../../update.html',T:'Update SmartMenus'},
{U:'../../../compatibility.html',T:'Compatibility tests'},
{U:'../../../Manual/forum.html',T:'Forum'},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author'}
]
);

s_add(
{N:'my_menu',LV:1,T:15,L:'mouseX+10',P:false,S:s_CSS1},
[
{U:'../../../Manual/manual.html',T:'User\'s Manual',Target:'self',SeparatorSize:0},
{U:'../../../Manual/forum.html',T:'Forum',Target:'self',SeparatorSize:0},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author',Target:'self'},
{U:'javascript:alert("SmartMenus (tm) 5\\nAdvanced DHTML navigation system.\\n\\nVersion: 5.5 (Release 31)\\nRelease date: March 16, 2005\\n\\n(c) 2001-2005 Vasil Dinkov - Plovdiv, BULGARIA\\n(c) 2003-2005 ET Vadikom-Vasil Dinkov\\nAll rights reserved.")',T:'About'}
]
);