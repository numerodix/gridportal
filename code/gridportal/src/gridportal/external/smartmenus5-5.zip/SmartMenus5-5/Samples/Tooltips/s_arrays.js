// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=50;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='newWindow';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSStooltip=[
'#000000',	// BorderColorDOM ('top right bottom left' or 'all')
'#000000',	// BorderColorNS4
1,		// BorderWidth
'#FFFFE1',	// BgColor
0,		// Padding
'#FFFFE1',	// ItemBgColor
'#FFFFE1',	// ItemOverBgColor
'#000000',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'normal',	// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
1,		// ItemPadding
1,		// ItemSeparatorSize
'#000000',	// ItemSeparatorColor
'blendtrans(duration=0.5)',	// IEfilter (look at Samples\IE4(5.5)Filters dirs)
false,		// UseSubImg
'',		// SubImgSrc
'',		// OverSubImgSrc
7,		// SubImgWidth
7,		// SubImgHeight
5,		// SubImgTop px (from item top)
'#8A8CCC',	// SELECTED ItemBgColor
'#FFFFFF',	// SELECTED ItemFontColor
'',		// SELECTED SubImgSrc
false,		// UseScrollingForTallMenus
'',		// ScrollingImgTopSrc
'',		// ScrollingImgBottomSrc
0,		// ScrollingImgWidth
0,		// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
0,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#FFFFFF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#FFFFFF',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];

s_CSSTop=['#4A49A8','#4A49A8',1,'#FFFFFF',2,'#CBCBEF','#4A49A8','#4A49A8','#FFFFFF','verdana,arial,helvetica,sans-serif','10px','1','bold','left',3,0,'#8A8CCC','',false,'','',0,0,0,'#8A8CCC','#FFFFFF','',true,'../../images/scrolltop.gif','../../images/scrollbottom.gif',68,12,'','','',0,'#CBCBEF','#FFFFFF','#FFFFFF',0,''];


// === 4 === MENU DEFINITIONS
s_add(
{
N:'search',	// NAME
LV:1,		// LEVEL (look at IMPORTANT NOTES 1 in the Manual)
MinW:130,	// MINIMAL WIDTH
T:15,		// TOP (look at IMPORTANT HOWTOS 6 in the Manual)
L:0,		// LEFT (look at IMPORTANT HOWTOS 6 in the Manual)
P:false,	// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSSTop	// STYLE Array to use for this menu
},
[		// define items {U:'url',T:'text' ...} look at the Manual for details
{U:'http://www.google.com/',T:'Google'},
{U:'http://www.altavista.com/',T:'Altavista'},
{U:'http://www.search.com/',T:'CNET Search.com'},
{U:'http://www.lycos.com/',T:'Lycos'},
{U:'http://www.hotbot.com/',T:'Hotbot'}
]
);

s_add(
{N:'e_mail',LV:1,MinW:130,T:15,L:74,P:false,S:s_CSSTop},
[
{U:'http://mail.yahoo.com/',T:'Yahoo!'},
{U:'http://www.hotmail.com/',T:'Hotmail'},
{U:'http://www.mail.com/',T:'Mail.com'},
{U:'http://www.mail.bg/',T:'Mail.bg'},
{U:'http://www.giga.de/',T:'Giga.de'}
]
);

s_add(
{N:'masters',LV:1,MinW:130,T:15,L:144,P:false,S:s_CSSTop},
[
{U:'http://www.hotscripts.com/',T:'HotScripts'},
{U:'http://www.builder.com/',T:'Builder'},
{U:'http://www.webreference.com/',T:'Webreference'},
{U:'http://msdn.microsoft.com/',T:'MSDN'},
{U:'http://www.perl.com/',T:'Perl'},
{U:'http://www.w3.org/',T:'W3C'}
]
);

s_add(
{N:'sports',LV:1,MinW:130,T:15,L:226,P:false,S:s_CSSTop},
[
{U:'http://www.manutd.com/',T:'Manchester United'},
{U:'http://www.nba.com/',T:'NBA'},
{U:'http://www.chelseafc.co.uk/',T:'Chelsea FC'},
{U:'http://www.fcbarcelona.com/',T:'FC Barcelona'},
{U:'http://www.lufc.co.uk/',T:'Leeds United FC'},
{U:'http://www.eurosport.com/',T:'Eurosport'},
{U:'http://www.espn.com/',T:'ESPN'},
{U:'http://www.umbro.com/',T:'UMBRO'}
]
);

s_add(
{N:'my_menu',LV:1,T:15,L:'mouseX+10',P:false,S:s_CSSTop},
[
{U:'../../Manual/manual.html',T:'User\'s Manual',Target:'self'},
{U:'../../Manual/forum.html',T:'Forum',Target:'self'},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author',Target:'self',SeparatorSize:1,SeparatorColor:'#FFFFFF'},
{U:'javascript:alert("SmartMenus (tm) 5\\nAdvanced DHTML navigation system.\\n\\nVersion: 5.5 (Release 31)\\nRelease date: February 20, 2005\\n\\n(c) 2001-2005 Vasil Dinkov - Plovdiv, BULGARIA\\n(c) 2003-2005 ET Vadikom-Vasil Dinkov\\nAll rights reserved.")',T:'About'}
]
);

s_add(
{N:'search_tip',LV:1,T:'mouseY+20',L:'',P:false,S:s_CSStooltip},
[
{U:'',T:'The best search engines.',NOROLL:true}
]
);

s_add(
{N:'e_mail_tip',LV:1,T:'mouseY+20',L:'',P:false,S:s_CSStooltip},
[
{U:'',T:'The best free e-mail providers.',NOROLL:true}
]
);

s_add(
{N:'masters_tip',LV:1,T:'mouseY+20',L:'',P:false,S:s_CSStooltip},
[
{U:'',T:'Useful sites for websmasters.',NOROLL:true}
]
);

s_add(
{N:'sports_tip',LV:1,T:'mouseY+20',L:'',P:false,S:s_CSStooltip},
[
{U:'',T:'My favorite sports sites.',NOROLL:true}
]
);

s_add(
{N:'author',LV:1,T:'mouseY+20',L:'',P:false,S:s_CSStooltip},
[
{U:'',T:'Click for the Help menu.',NOROLL:true}
]
);