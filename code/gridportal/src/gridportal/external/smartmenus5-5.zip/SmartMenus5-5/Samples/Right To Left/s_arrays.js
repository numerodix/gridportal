// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=true;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='newWindow';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSSTop=[
'#4A49A8',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
1,		// BorderWidth
'#F6F6F8',	// BgColor
2,		// Padding
'#F6F6F8',	// ItemBgColor
'#CBCBEF',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#4A49A8',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'right',	// ItemTextAlign (left/center/right)
3,		// ItemPadding
0,		// ItemSeparatorSize
'#8A8CCC',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
true,					// UseSubImg
'../../images/arrow_rtl.gif',		// SubImgSrc
'../../images/arrow_rtl.gif',		// OverSubImgSrc
7,					// SubImgWidth
7,					// SubImgHeight
6,					// SubImgTop px (from item top)
'#8A8CCC',				// SELECTED ItemBgColor
'#FFFFFF',				// SELECTED ItemFontColor
'../../images/arrowover_rtl.gif',	// SELECTED SubImgSrc
true,					// UseScrollingForTallMenus
'../../images/scrolltop.gif',		// ScrollingImgTopSrc
'../../images/scrollbottom.gif',	// ScrollingImgBottomSrc
68,					// ScrollingImgWidth
12,					// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
1,		// ItemBorderWidth
'#F6F6F8',	// ItemBorderColor ('top right bottom left' or 'all')
'#4A49A8',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#8A8CCC',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];


// === 4 === MENU DEFINITIONS
s_add(
{
N:'sub_demo',	// NAME
LV:1,		// LEVEL (look at IMPORTANT NOTES 1 in the Manual)
MinW:140,	// MINIMAL WIDTH
T:15,		// TOP (look at IMPORTANT HOWTOS 6 in the Manual)
L:'mouseX+10',	// LEFT (look at IMPORTANT HOWTOS 6 in the Manual)
P:false,	// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSSTop	// STYLE Array to use for this menu
},
[
{Show:'bg_stuff',U:'http://www.gbg.bg/',T:'Bulgarian stuff'},
{U:'http://www.fifa.com/',T:'King football'},
{Show:'my_music',U:'',T:'My favourite music'}
]
);

	s_add(
	{N:'bg_stuff',LV:2,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
	[
	{Show:'bg_portals',U:'',T:'Portals'},
	{Show:'bg_search',U:'',T:'Search',SeparatorSize:0},
	{Show:'bg_misc',U:'http://www.gbg.bg/',T:'Misc',SELECTED:true}
	]
	);

		s_add(
		{N:'bg_portals',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.hit.bg/',T:'HIT.bg'},
		{U:'http://www.dir.bg/',T:'DIR.bg'},
		{U:'http://www.top.bg/',T:'TOP.bg'},
		{U:'http://www.gbg.bg/',T:'Gyuvetch'},
		{U:'http://www.search.bg/',T:'Search.bg'}
		]
		);

		s_add(
		{N:'bg_search',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.search.bg/',T:'Search.bg'},
		{U:'http://www.rambler.bg/',T:'Rambler'},
		{U:'http://www.dir.bg/',T:'DIR.bg'},
		{U:'http://www.mp3-bg.com/',T:'MP3-BG.com'}
		]
		);

		s_add(
		{N:'bg_misc',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.news-bg.com/',T:'News-BG'},
		{U:'http://www.bnt.bg/',T:'Bulgarian National Television'},
		{U:'http://www.darik.net/',T:'Darik radio'},
		{U:'http://www.7sport.net/',T:'7 Days Sport'},
		{U:'http://www.btv.bg/',T:'bTV'}
		]
		);

	s_add(
	{N:'my_music',LV:2,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
	[
	{U:'http://www.u2.com/',T:'U2'},
	{U:'http://www.depechemode.com/',T:'Depeche Mode'},
	{U:'http://www.sting.com/',T:'Sting'},
	{U:'http://www.sade.com/',T:'Sade'},
	{U:'http://www.garbage.com/',T:'Garbage'},
	{U:'http://www.thecorrswebsite.com/',T:'The Corrs'},
	{U:'http://www.republica.com/',T:'Republica'}
	]
	);