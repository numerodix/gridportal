===========================================
 ShadowFX Add-on
===========================================

 This add-on is still not ready for SmartMenus 5.