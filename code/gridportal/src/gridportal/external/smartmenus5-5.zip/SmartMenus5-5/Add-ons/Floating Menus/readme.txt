// MAXIMIZE THE WINDOW TO SEE THIS FILE

Just copy and paste the code in script.txt to your s_arrays.js file. After doing this, you will
be able to use the following new menu properties:

FTX (true/false) float the menu horizontally
FTY (true/false) float the menu vertically
FTT (number or JavaScript expression) desired top position for the menu (if not set 0 is used)
FTL (number or JavaScript expression) desired left position for the menu (if not set 0 is used)
FTB (number or JavaScript expression) max bottom position for the menu from the page top edge
FTR (number or JavaScript expression) max right position for the menu from the page left edge

All of the above properties are optional and you can use them for as many menus as you like.