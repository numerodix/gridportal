// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='self';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSSTop=[
'#DBDCEF #4A49A8 #4A49A8 #DBDCEF',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
1,		// BorderWidth
'#CBCBEF',	// BgColor
2,		// Padding
'#CBCBEF',	// ItemBgColor
'#8A8CCC',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
2,		// ItemPadding
0,		// ItemSeparatorSize
'transparent',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
false,		// UseSubImg
'',		// SubImgSrc
'',		// OverSubImgSrc
7,		// SubImgWidth
7,		// SubImgHeight
5,		// SubImgTop px (from item top)
'#FFFFFF',	// SELECTED ItemBgColor
'#4A49A8',	// SELECTED ItemFontColor
'',		// SELECTED SubImgSrc
false,		// UseScrollingForTallMenus
'',		// ScrollingImgTopSrc
'',		// ScrollingImgBottomSrc
68,		// ScrollingImgWidth
12,		// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
1,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#DBDCEF #4A49A8 #4A49A8 #DBDCEF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#8A8CCC',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];


// FLOATING MENUS ADD-ON
s_FT=[];function s_initFloaters(){if(typeof s_ML=="undefined"){setTimeout("s_initFloaters()",1000);return};for(var i=1;i<=s_ct;i++){if(s_[i][0].FTX||s_[i][0].FTY){s_FT[s_FT.length]={i:i,x:0,y:0};if(s_[i][0].FTY)s_[i][0].T='s_FTpos('+i+',\''+s_[i][0].T+'\')';if(s_[i][0].FTX)s_[i][0].L='s_FTpos('+i+',\''+s_[i][0].L+'\',1)'}}if(s_FT.length>0)s_setFloaters()};function s_FTpos(i,p,l){var s,t,b;s=s_iE?l?s_dE.scrollLeft:s_dE.scrollTop:l?pageXOffset:pageYOffset;t=l?s_[i][0].FTL?eval(s_[i][0].FTL):0:s_[i][0].FTT?eval(s_[i][0].FTT):0;b=l?s_[i][0].FTR?eval(s_[i][0].FTR):0:s_[i][0].FTB?eval(s_[i][0].FTB):0;p=eval(p);return s+t<p?p:!b||b>s+t+s_getDim(s_[i][0].N,l?"w":"h")||b<p+s_getDim(s_[i][0].N,l?"w":"h")?s+t:b-s_getDim(s_[i][0].N,l?"w":"h")};function s_setFloaters(){var x,y,i,I,o,px=s_oP7m||s_nS4?0:"px";x=s_iE?s_dE.scrollLeft:pageXOffset;y=s_iE?s_dE.scrollTop:pageYOffset;for(i=0;i<s_FT.length;i++){I=s_FT[i].i;o=s_nS4?document.layers["s_m"+I]:s_getOS("s_m"+I);if(s_[I][0].FTY){if(s_FT[i].y==y)o.top=eval(s_[I][0].T)+px;s_FT[i].y=y}if(s_[I][0].FTX){if(s_FT[i].x==x)o.left=eval(s_[I][0].L)+px;s_FT[i].x=x}};setTimeout("s_setFloaters()",300)};s_initFloaters();
// FLOATING MENUS ADD-ON


// === 4 === MENU DEFINITIONS
s_add(
{N:'test_menu',LV:1,W:150,T:60,L:30,P:true,S:s_CSSTop,

FTY:true,FTX:true,FTT:10,FTL:10  // the properties used to make the menu floating

},
[
{U:'',T:'SmartMenus 5',TextAlign:'center',SELECTED:true,SeparatorSize:2},
{U:'http://www.smartmenus.org/',T:'SmartMenus.org'},
{U:'http://www.smartmenus.org/',T:'SmartMenus.org'},
{U:'http://www.smartmenus.org/',T:'SmartMenus.org'},
{U:'http://www.smartmenus.org/',T:'SmartMenus.org'}
]
);