============================================
 Frame support add-on scripts
============================================

IMPORTANT
 To learn how to use the SmartMenus with framed pages (the toolbar in
 one frame and the menus appearing in other) just open the "example"
 folder and then index.html.