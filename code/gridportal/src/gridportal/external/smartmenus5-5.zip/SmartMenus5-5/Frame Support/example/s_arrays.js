// USE WORDWRAP AND MAXIMIZE THE WINDOW TO SEE THIS FILE
// v5

// === 1 === EXTRAS
s_hideTimeout=500;//1000=1 second
s_subShowTimeout=300;//if <=100 the menus will function like SM4.x
s_subMenuOffsetX=4;//pixels (if no subs, leave as you like)
s_subMenuOffsetY=1;
s_keepHighlighted=true;
s_autoSELECTED=false;//make the item linking to the current page SELECTED
s_autoSELECTEDItemsClickable=false;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTree=true;//look at IMPORTANT NOTES 1 in the Manual
s_autoSELECTEDTreeItemsClickable=true;//look at IMPORTANT NOTES 1 in the Manual
s_scrollingInterval=30;//scrolling for tall menus
s_rightToLeft=false;
s_hideSELECTsInIE=false;//look at IMPORTANT HOWTOS 7 in the Manual


// === 2 === Default TARGET for all the links
// for navigation to frame, calling functions or
// different target for any link look at
// IMPORTANT HOWTOS 1 NOTES in the Manual
s_target='newWindow';//(newWindow/self/top)


// === 3 === STYLESHEETS- you can define different arrays and then assign
// them to any menu you want with the s_add() function
s_CSSTop=[
'#4A49A8',	// BorderColorDOM ('top right bottom left' or 'all')
'#4A49A8',	// BorderColorNS4
1,		// BorderWidth
'#CBCBEF',	// BgColor
1,		// Padding
'#CBCBEF',	// ItemBgColor
'#4A49A8',	// ItemOverBgColor
'#4A49A8',	// ItemFontColor
'#FFFFFF',	// ItemOverFontColor
'verdana,arial,helvetica,sans-serif',	// ItemFontFamily
'10px',		// ItemFontSize (css)
'1',		// ItemFontSize Netscape4 (look at KNOWN BUGS 3 in the Manual)
'bold',		// ItemFontWeight (bold/normal)
'left',		// ItemTextAlign (left/center/right)
3,		// ItemPadding
1,		// ItemSeparatorSize
'#8A8CCC',	// ItemSeparatorColor
'',		// IEfilter (look at Samples\IE4(5.5)Filters dirs)
true,				// UseSubImg
'../../images/arrow.gif',	// SubImgSrc
'../../images/arrowover.gif',	// OverSubImgSrc
7,				// SubImgWidth
7,				// SubImgHeight
5,				// SubImgTop px (from item top)
'#8A8CCC',			// SELECTED ItemBgColor
'#FFFFFF',			// SELECTED ItemFontColor
'../../images/arrowover.gif',	// SELECTED SubImgSrc
true,				// UseScrollingForTallMenus
'../../images/scrolltop.gif',	// ScrollingImgTopSrc
'../../images/scrollbottom.gif',// ScrollingImgBottomSrc
68,				// ScrollingImgWidth
12,				// ScrollingImgHeight
'',		// ItemClass (css)
'',		// ItemOverClass (css)
'',		// SELECTED ItemClass (css)
0,		// ItemBorderWidth
'#CBCBEF',	// ItemBorderColor ('top right bottom left' or 'all')
'#FFFFFF',	// ItemBorderOverColor ('top right bottom left' or 'all')
'#FFFFFF',	// SELECTED ItemBorderColor ('top right bottom left' or 'all')
0,		// ItemSeparatorSpacing
''		// ItemSeparatorBgImage
];

s_CSSred=['#EEEDF5 #4A49A8 #4A49A8 #EEEDF5','#ff0000',1,'#fffbf0',2,'#fffbf0','#bebddf','#ff0000','#000000','arial,helvetica,sans-serif','10pt','2','normal','center',5,1,'#bebddf','',true,'../../images/arrow2.gif','../../images/arrow3.gif',7,7,9,'#C0C0C0','#FFFFFF','../../images/arrow2.gif',true,'../../images/scrolltop.gif','../../images/scrollbottom.gif',68,12,'','','',2,'#fffbf0','#8583BE #DDDCEA #DDDCEA #8583BE','#ff0000',1,'../../images/separator_bg.gif'];


// === 4 === MENU DEFINITIONS
s_add(
{
N:'search',	// NAME
LV:1,		// LEVEL (look at IMPORTANT NOTES 1 in the Manual)
MinW:130,	// MINIMAL WIDTH
T:-1,		// TOP (look at IMPORTANT HOWTOS 6 in the Manual)
L:0,		// LEFT (look at IMPORTANT HOWTOS 6 in the Manual)
P:false,	// menu is PERMANENT (you can only set true if this is LEVEL 1 menu)
S:s_CSSTop	// STYLE Array to use for this menu
},
[		// define items {U:'url',T:'text' ...} look at the Manual for details
{U:'http://www.google.com/',T:'Google'},
{U:'http://www.altavista.com/',T:'Altavista'},
{U:'http://www.search.com/',T:'CNET Search.com'},
{U:'http://www.lycos.com/',T:'Lycos'},
{U:'http://www.hotbot.com/',T:'Hotbot'}
]
);

s_add(
{N:'e_mail',LV:1,MinW:130,T:-1,L:74,P:false,S:s_CSSTop},
[
{U:'http://mail.yahoo.com/',T:'Yahoo!'},
{U:'http://www.hotmail.com/',T:'Hotmail'},
{U:'http://www.mail.com/',T:'Mail.com'},
{U:'http://www.mail.bg/',T:'Mail.bg'},
{U:'http://www.giga.de/',T:'Giga.de'}
]
);

s_add(
{N:'masters',LV:1,MinW:130,T:-1,L:144,P:false,S:s_CSSTop},
[
{U:'http://www.hotscripts.com/',T:'HotScripts'},
{U:'http://www.builder.com/',T:'Builder'},
{U:'http://www.webreference.com/',T:'Webreference'},
{U:'http://msdn.microsoft.com/',T:'MSDN'},
{U:'http://www.perl.com/',T:'Perl'},
{U:'http://www.w3.org/',T:'W3C'}
]
);

s_add(
{N:'sports',LV:1,MinW:130,T:-1,L:226,P:false,S:s_CSSTop},
[
{U:'http://www.manutd.com/',T:'Manchester United'},
{U:'http://www.nba.com/',T:'NBA'},
{U:'http://www.chelseafc.co.uk/',T:'Chelsea FC'},
{U:'http://www.fcbarcelona.com/',T:'FC Barcelona'},
{U:'http://www.lufc.co.uk/',T:'Leeds United FC'},
{U:'http://www.eurosport.com/',T:'Eurosport'},
{U:'http://www.espn.com/',T:'ESPN'},
{U:'http://www.umbro.com/',T:'UMBRO'}
]
);

s_add(
{N:'sub_demo',LV:1,MinW:130,T:-1,L:296,P:false,S:s_CSSTop},
[
{Show:'bg_stuff',U:'http://www.gbg.bg/',T:'Bulgarian stuff'},
{U:'http://www.fifa.com/',T:'King football'},
{Show:'my_music',U:'',T:'My favourite music'}
]
);

	s_add(
	{N:'bg_stuff',LV:2,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
	[
	{Show:'bg_portals',U:'',T:'Portals'},
	{Show:'bg_search',U:'',T:'Search',SeparatorSize:0},
	{Show:'bg_misc',U:'http://www.gbg.bg/',T:'Misc',SELECTED:true}
	]
	);

		s_add(
		{N:'bg_portals',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.hit.bg/',T:'HIT.bg'},
		{U:'http://www.dir.bg/',T:'DIR.bg'},
		{U:'http://www.top.bg/',T:'TOP.bg'},
		{U:'http://www.gbg.bg/',T:'Gyuvetch'},
		{U:'http://www.search.bg/',T:'Search.bg'}
		]
		);

		s_add(
		{N:'bg_search',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.search.bg/',T:'Search.bg'},
		{U:'http://www.rambler.bg/',T:'Rambler'},
		{U:'http://www.dir.bg/',T:'DIR.bg'},
		{U:'http://www.mp3-bg.com/',T:'MP3-BG.com'}
		]
		);

		s_add(
		{N:'bg_misc',LV:3,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
		[
		{U:'http://www.news-bg.com/',T:'News-BG'},
		{U:'http://www.bnt.bg/',T:'Bulgarian National Television'},
		{U:'http://www.darik.net/',T:'Darik radio'},
		{U:'http://www.7sport.net/',T:'7 Days Sport'},
		{U:'http://www.btv.bg/',T:'bTV'},
		{Show:'sub4',U:'',T:'More subs &amp; different CSS'}
		]
		);

			s_add(
			{N:'sub4',LV:4,MinW:130,T:'',L:'',P:false,S:s_CSSred},
			[
			{U:'http://www.smartmenus.org/',T:'SmartMenus'},
			{U:'',T:'NOROLL',NOROLL:true},
			{U:'http://www.smartmenus.org/',T:'SmartMenus'},
			{U:'http://www.smartmenus.org/',T:'SmartMenus'},
			{Show:'sub5',U:'',T:'more'},
			{U:'http://www.smartmenus.org/',T:'SmartMenus'}
			]
			);

				s_add(
				{N:'sub5',LV:5,MinW:130,T:'',L:'',P:false,S:s_CSSTop,B:'#FFFFFF'},
				[
				{U:'http://www.smartmenus.org/',
				 T:'SmartMenus',SeparatorColor:'#ffffff'},
				{U:'http://www.smartmenus.org/',
				 T:'NOROLL+link',NOROLL:true,
				 SeparatorColor:'#ffffff'},
				{U:'http://www.smartmenus.org/',
				 T:'SmartMenus',SeparatorSize:0},
				{U:'http://www.smartmenus.org/',
				 T:'SmartMenus',SeparatorSize:0},
				{Show:'sub6',U:'',T:'more',SeparatorSize:0},
				{U:'http://www.smartmenus.org/',T:'SmartMenus'}
				]
				);

					s_add(
					{N:'sub6',LV:6,MinW:130,T:'',L:'',P:false,S:s_CSSTop,
					 B:'#FFFFFF',BC:'#DBDCEF #4A49A8 #4A49A8 #DBDCEF'},
					[
					{U:'http://www.smartmenus.org/',T:'SmartMenus',
					 BgColor:'#FFC0C0',OverBgColor:'#C00000'},
					{U:'http://www.smartmenus.org/',T:'SmartMenus',
					 BgColor:'#FFFFC0',OverBgColor:'#C0C000'},
					{U:'http://www.smartmenus.org/',T:'SmartMenus',
					 BgColor:'#C0FFC0',OverBgColor:'#00C000'},
					{U:'http://www.smartmenus.org/',T:'SmartMenus',
					 BgColor:'#C0FFFF',OverBgColor:'#00C0C0'}
					]
					);

	s_add(
	{N:'my_music',LV:2,MinW:130,T:'',L:'',P:false,S:s_CSSTop},
	[
	{U:'http://www.u2.com/',T:'U2'},
	{U:'http://www.depechemode.com/',T:'Depeche Mode'},
	{U:'http://www.sting.com/',T:'Sting'},
	{U:'http://www.sade.com/',T:'Sade'},
	{U:'http://www.garbage.com/',T:'Garbage'},
	{U:'http://www.thecorrswebsite.com/',T:'The Corrs'},
	{U:'http://www.republica.com/',T:'Republica'}
	]
	);

s_add(
{N:'my_menu',LV:1,T:-1,L:'mouseX+10',P:false,S:s_CSSTop},
[
{U:'../../Manual/manual.html',T:'User\'s Manual',Target:'top',SeparatorSize:0},
{U:'../../Manual/forum.html',T:'Forum',Target:'top',SeparatorSize:0},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author',Target:'self'},
{U:'javascript:alert("SmartMenus (tm) 5\\nAdvanced DHTML navigation system.\\n\\nVersion: 5.5 (Release 31)\\nRelease date: March 16, 2005\\n\\n(c) 2001-2005 Vasil Dinkov - Plovdiv, BULGARIA\\n(c) 2003-2005 ET Vadikom-Vasil Dinkov\\nAll rights reserved.")',T:'About'}
]
);

s_add(
{N:'mouse_relative',LV:1,MinW:130,T:'mouseY+16',L:'mouseX+16',P:false,S:s_CSSTop},
[
{U:'',T:'Mouse position relative DEMO',SELECTED:true,SeparatorColor:'#ffffff'},
{U:'../../update.html',T:'&nbsp;Update SmartMenus',Image:["../../images/ico.gif",12,12],ImageA:'top',Target:'top'},
{U:'mailto:smartmenus@smartmenus.org',T:'Contact the author',Target:'self'}
]
);