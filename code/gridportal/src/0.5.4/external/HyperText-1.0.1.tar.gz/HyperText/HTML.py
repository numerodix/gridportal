from HTML40 import *
