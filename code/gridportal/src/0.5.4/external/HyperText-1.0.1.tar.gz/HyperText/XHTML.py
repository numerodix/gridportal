from XHTML10 import *
